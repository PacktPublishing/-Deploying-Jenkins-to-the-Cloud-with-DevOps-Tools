
## Verify DNS is working
```
nslookup jenkins.cloudci.net
```